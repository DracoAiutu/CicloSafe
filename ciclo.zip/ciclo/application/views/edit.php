<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title><?php  echo $title; ?> </title>
</head>
<body>
	
<form method="post" action="<?php echo base_url('/index.php/usuario/atualizar').'/'.$usuarios->id_usuario ?>">
  name:<br>
  <input type="text" name="nome" value="<?php echo $usuarios->nome; ?>"><br>
  matricula:<br>
  <input type="text" name="matricula" value="<?php echo $usuarios->matricula; ?>"><br>
  uid_card:<br>
  <input type="text" name="uid_card" value="<?php echo $usuarios->uid_card; ?>"><br>
  id_bike:<br>
  <input type="text" name="id_bike" value="<?php echo $usuarios->id_bike; ?>"><br>
 <input type="submit" value="Editar"> 
</form>

</body>
</html>

