<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8">
	<title><?php echo $title; ?></title>
</head>
<body>
	<h1> <?php echo $pagina; ?></h1>
	<table border="1">	
<tr> 
	<th>
		Nome
	</th>
	<th>
		Matricula
	</th>
	<th>
		ID Cartão
	</th>
	<th>
		ID Bike
	</th>
	<th>deletar</th>
	<th>editar</th>
</tr>
<?php foreach ($usuarios as $key => $value) {
?>
	
	<tr>
		<td><?php echo $value->nome;  ?></td>
		<td><?php echo $value->matricula;  ?></td>
		<td><?php echo $value->uid_card;  ?></td>
		<td><?php echo $value->id_bike;  ?></td>

		<td><a href="<?php echo base_url('/index.php/usuario/deletar')."/".$value->id_usuario?>">deletar</a></td>
		<td><a href="<?php echo base_url('/index.php/usuario/editar')."/".$value->id_usuario ?>">editar</a></td>

	</tr>
<?php } ?>
	</table>
	<button name="cradastrar" ><a href="<?php echo base_url('/index.php/usuario/criar')?>">cadastrar</a></button>

</body>
</html>