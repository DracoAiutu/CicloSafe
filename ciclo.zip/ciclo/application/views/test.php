<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title><?php  echo $title;?> </title>
</head>
<body>
	
<form method="POST" action="<?php echo base_url('/index.php/usuario/salvar')?>">
  name:<br>
  <input type="text" name="nome"><br>
  matricula:<br>
  <input type="text" name="matricula"><br>
  uid_card:<br>
  <input type="text" name="uid_card"><br>
  id_bike:<br>
  <input type="text" name="id_bike"><br>
 <input type="submit" value="Submit">
</form>

</body>
</html>



