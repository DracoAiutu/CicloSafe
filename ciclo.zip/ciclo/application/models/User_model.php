<?php
class User_model extends CI_Model
{
	public $id;
	public $nome;
	public $uid_card;
	public $id_bike;
	public $matricula;
	
	public function __construct(){
		 parent::__construct();
	}
	public function inserir()
	{
		$dados = array("nome" => $this->nome, "matricula"=> $this->matricula,"uid_card"=> $this->uid_card,"id_bike"=> $this->id_bike);
		
		$this->load->database();
		return $this->db->insert('usuario', $dados);
	}
	public function recuperar(){
		$this->load->database();
		$query = $this->db->get('usuario');
		return $query->result();
	}

    public function delete($id)
    {
    	$this->load->database();
        $this->db->where('id_usuario', $id);
        $this->db->delete('usuario');
    }
    public function recuperarUm($id){
    	$this->load->database();
        $this->db->where('id_usuario',$id);
        $query = $this->db->get('usuario');
        return $query->row();
    }
    public function update(){
    	$this->load->database();
		$this->db->set('nome', $this->nome);
		$this->db->set('matricula', $this->matricula);
		$this->db->set('uid_card', $this->uid_card);
		$this->db->set('id_bike', $this->id_bike);
        $this->db->where('id_usuario', $this->id_usuario);	
        
   		$this->db->update('usuario');

    }
}