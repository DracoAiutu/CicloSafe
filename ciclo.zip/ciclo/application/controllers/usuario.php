<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Usuario extends CI_Controller {

	
	public function index()
	{
			$coisas['pagina'] = 'listar';
			$coisas['title'] = 'listar';

			$this->load->model('User_model');	
 			$coisas['usuarios'] = $this->User_model->recuperar();
             $this->load->view('list', $coisas);
	}
	public function salvar()
    {
    	$this->load->model('User_model');	
        
        $nome = $_POST['nome'];
        $matricula = $_POST['matricula'];
        $uid_card = $_POST['uid_card'];
        $id_bike = $_POST['id_bike'];
        
  
       
        $this->User_model->nome = $nome;
        $this->User_model->matricula = $matricula;
        $this->User_model->uid_card = $uid_card;
        $this->User_model->id_bike = $id_bike;
      
        $insertar = $this->User_model->inserir();


        if ($insertar) {
        	$coisas['pagina'] = 'listagem de users';
        	$coisas['title'] = 'listagem de users';
            $coisas['usuarios'] = $this->User_model->recuperar();
            return $this->load->view('list', $coisas);
        } else {
            $coisas ['error'] = 'usuário não inserido na base de dados';
            return $this->load->view('test');
        }
    }
		public function deletar(){
          
            $this->load->model('User_model');
            $id = $this->uri->segment(3);
		
            $this->User_model->delete($id);
            redirect('index.php/usuario/index');
        }
        public function editar(){
	        $this->load->model('User_model');
	        $id = $this->uri->segment(3);
	        $usuario = $this->User_model->recuperarUm($id);
            $dados['title'] = "Edição de usuarios";
            $dados['pagina'] = "Edição de usuarios";
            $dados['usuarios'] = $this->User_model->recuperarUm($id);


	        return $this->load->view('edit', $dados);
        }
        public function criar(){
        	$this->load->view('test');

        }
         public function atualizar(){
            $this->load->model('User_model');
            $this->User_model->id = $this->uri->segment(3);
            $this->User_model->nome = $_POST['nome'];
            $this->User_model->matricula = $_POST['matricula'];
            $this->User_model->uid_card = $_POST['uid_card'];
            $this->User_model->id_bike = $_POST['id_bike'];
      
            $this->User_model->update();
            redirect('index.php/usuario/index');
        }
}
